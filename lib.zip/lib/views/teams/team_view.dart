import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sar_track/views/dashboard/dashboard_view.dart';
import 'package:sar_track/views/profile/profile_view.dart';
import 'package:sar_track/views/tracking/map_view.dart';
import 'package:sar_track/controllers/tracking_controller.dart';
import 'package:sar_track/controllers/team_controller.dart';
import 'package:sar_track/controllers/auth_controller.dart';
import 'package:sar_track/models/tracker_model.dart';
import 'package:sar_track/models/team_model.dart';

class TeamView extends StatelessWidget {
  const TeamView({super.key});

  @override
  Widget build(BuildContext context) {
    final trackingController = Get.put(TrackingController());
    final teamController = Get.put(TeamController());
    // AuthController seharusnya sudah diregistrasi sejak login,
    // pakai find supaya tidak reset session yang sedang berjalan.
    final authController = Get.find<AuthController>();

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header: Nama Tim + Badge Peran ───────────────────────
              Obx(() {
                final team = teamController.activeTeam.value;
                final myUid = authController.currentUser.value?.uid;
                final isCreator = _isTeamCreator(team, myUid);

                return Row(
                  children: [
                    Expanded(
                      child: Text(
                        team?.teamName ?? "Team",
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF131A26),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (team != null) _buildRoleBadge(isCreator),
                  ],
                );
              }),

              // ── Kode Tim — HANYA tampil untuk pembuat tim ────────────
              Obx(() {
                final team = teamController.activeTeam.value;
                final myUid = authController.currentUser.value?.uid;
                final isCreator = _isTeamCreator(team, myUid);

                if (team == null || !isCreator) return const SizedBox.shrink();

                return Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: _buildTeamCodeCard(context, team.teamId),
                );
              }),

              const SizedBox(height: 24),

              // ── Daftar Anggota Tim ────────────────────────────────────
              Expanded(
                child: Obx(() {
                  final members = trackingController.teamTrackers;
                  final team = teamController.activeTeam.value;
                  final creatorUid = (team != null && team.members.isNotEmpty)
                      ? team.members.first
                      : null;

                  if (team == null) {
                    return const Center(
                      child: Text("Anda belum tergabung dalam tim."),
                    );
                  }

                  if (members.isEmpty) {
                    return const Center(
                      child: Text("Belum ada anggota tim yang aktif."),
                    );
                  }

                  return ListView.separated(
                    itemCount: members.length,
                    separatorBuilder: (context, index) =>
                        const SizedBox(height: 16),
                    itemBuilder: (context, index) {
                      final member = members[index];
                      final isMemberCreator = member.uid == creatorUid;
                      return _buildTeamCard(member, isMemberCreator);
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),
      // FAB share kode tim — hanya muncul untuk pembuat tim
      floatingActionButton: Obx(() {
        final team = teamController.activeTeam.value;
        final myUid = authController.currentUser.value?.uid;
        final isCreator = _isTeamCreator(team, myUid);

        if (team == null || !isCreator) return const SizedBox.shrink();

        return FloatingActionButton(
          onPressed: () => _showTeamCodeSheet(context, team.teamId),
          backgroundColor: const Color(0xFFFF6600),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 4,
          child: const Icon(Icons.person_add_alt_1, color: Colors.white),
        );
      }),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  // ─── Helper: Cek apakah UID adalah pembuat tim (member pertama) ───────
  bool _isTeamCreator(TeamModel? team, String? uid) {
    if (team == null || uid == null) return false;
    if (team.members.isEmpty) return false;
    return team.members.first == uid;
  }

  // ─── Badge Peran: Pembuat (emas) vs Anggota (biru) ────────────────────
  Widget _buildRoleBadge(bool isCreator) {
    final bgColor = isCreator
        ? const Color(0xFFFFF3E0)
        : const Color(0xFFE3F2FD);
    final textColor = isCreator
        ? const Color(0xFFE65100)
        : const Color(0xFF1565C0);
    final label = isCreator ? "👑 Tim Anda" : "🔗 Bergabung";

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  // ─── Card Kode Tim dengan tombol Copy ──────────────────────────────────
  Widget _buildTeamCodeCard(BuildContext context, String teamId) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFB74D)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Kode Undangan Tim",
                  style: TextStyle(fontSize: 12, color: Color(0xFF8D6E63)),
                ),
                Text(
                  teamId,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    color: Color(0xFFE65100),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: teamId));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Kode tim disalin ke clipboard")),
              );
            },
            icon: const Icon(Icons.copy, color: Color(0xFFE65100)),
            tooltip: "Salin kode tim",
          ),
        ],
      ),
    );
  }

  // ─── Bottom Sheet share kode tim dari FAB ──────────────────────────────
  void _showTeamCodeSheet(BuildContext context, String teamId) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Undang Anggota Baru",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                "Bagikan kode ini agar anggota lain bisa bergabung ke tim Anda.",
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),
              const SizedBox(height: 16),
              _buildTeamCodeCard(context, teamId),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  // ─── Card Anggota Tim (highlight khusus untuk pembuat) ─────────────────
  Widget _buildTeamCard(TrackerModel member, bool isCreator) {
    Color statusColor;
    Color statusBgColor;
    Color statusDotColor;

    switch (member.status) {
      case MemberStatus.online:
        statusColor = const Color(0xFF2E7D32);
        statusBgColor = const Color(0xFFE8F5E9);
        statusDotColor = const Color(0xFF4CAF50);
        break;
      case MemberStatus.busy:
        statusColor = const Color(0xFFD84315);
        statusBgColor = const Color(0xFFFBE9E7);
        statusDotColor = const Color(0xFFFF9800);
        break;
      case MemberStatus.sos:
        statusColor = const Color(0xFFC62828);
        statusBgColor = const Color(0xFFFFEBEE);
        statusDotColor = const Color(0xFFF44336);
        break;
      case MemberStatus.offline:
      default:
        statusColor = const Color(0xFF616161);
        statusBgColor = const Color(0xFFEEEEEE);
        statusDotColor = const Color(0xFF9E9E9E);
    }

    final imageUrl =
        "https://ui-avatars.com/api/?name=${Uri.encodeComponent(member.username)}&background=random";

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        // Card pembuat tim diberi tint emas tipis agar beda dari anggota biasa
        color: isCreator ? const Color(0xFFFFFDF5) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCreator ? const Color(0xFFFFD54F) : Colors.grey.shade300,
          width: isCreator ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: NetworkImage(imageUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: statusDotColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Row(
              children: [
                Flexible(
                  child: Text(
                    member.username,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF131A26),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (isCreator) ...[
                  const SizedBox(width: 6),
                  const Text("👑", style: TextStyle(fontSize: 14)),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: statusBgColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              member.statusLabel,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: statusColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F3F5),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        border: Border.all(color: Colors.grey.shade300, width: 1),
      ),
      child: SafeArea(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildNavItem(
              Icons.assignment,
              "Missions",
              false,
              onTap: () {
                Get.offAll(
                  () => const DashboardView(),
                  transition: Transition.noTransition,
                );
              },
            ),
            _buildNavItem(
              Icons.map_outlined,
              "Map",
              false,
              onTap: () {
                Get.offAll(
                  () => const MapView(),
                  transition: Transition.noTransition,
                );
              },
            ),
            _buildNavItem(Icons.people, "Teams", true),
            _buildNavItem(
              Icons.account_circle_outlined,
              "Account",
              false,
              onTap: () {
                Get.offAll(
                  () => const ProfileView(),
                  transition: Transition.noTransition,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
    IconData icon,
    String label,
    bool isSelected, {
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFFF6600) : Colors.transparent,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected
                  ? const Color(0xFF131A26)
                  : const Color(0xFF495057),
              size: 22,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                color: isSelected
                    ? const Color(0xFF131A26)
                    : const Color(0xFF495057),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
