import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sar_track/controllers/team_controller.dart';

class CreateTeamView extends StatelessWidget {
  const CreateTeamView({super.key});

  @override
  Widget build(BuildContext context) {
    final teamController = Get.put(TeamController());
    final teamNameController = TextEditingController();

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF131A26)),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          "Buat Tim Baru",
          style: TextStyle(
            color: Color(0xFF131A26),
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Nama Tim",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF495057),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: teamNameController,
              onChanged: (_) => teamController.clearError(),
              decoration: InputDecoration(
                hintText: "Masukkan nama tim",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: Color(0xFFFF6600),
                    width: 2,
                  ),
                ),
              ),
            ),

            // Tampilkan pesan error dari TeamController kalau ada
            Obx(() {
              if (teamController.errorMessage.value.isEmpty) {
                return const SizedBox.shrink();
              }
              return Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  teamController.errorMessage.value,
                  style: const TextStyle(color: Colors.red, fontSize: 13),
                ),
              );
            }),

            const SizedBox(height: 24),
            const Text(
              "Deskripsi Misi (Opsional)",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF495057),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              maxLines: 4,
              decoration: InputDecoration(
                hintText: "Jelaskan tujuan atau misi tim...",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: Color(0xFFFF6600),
                    width: 2,
                  ),
                ),
              ),
              // Catatan: field deskripsi misi belum ada di TeamModel/blueprint.
              // Saat ini hanya UI saja, belum disimpan ke Firebase.
              // Tambahkan field 'description' ke TeamModel kalau memang dibutuhkan.
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: Obx(
                () => ElevatedButton(
                  onPressed: teamController.isLoading.value
                      ? null
                      : () async {
                          await teamController.createTeam(
                            teamNameController.text,
                          );

                          // createTeam() sudah handle error secara reaktif lewat
                          // errorMessage. Kalau berhasil, activeTeam akan terisi
                          // dan controller otomatis navigasi ke /tracking.
                          if (teamController.errorMessage.value.isEmpty &&
                              teamController.activeTeam.value != null) {
                            Get.snackbar(
                              "Berhasil",
                              "Tim '${teamController.activeTeam.value!.teamName}' berhasil dibuat",
                              backgroundColor: Colors.green,
                              colorText: Colors.white,
                              snackPosition: SnackPosition.BOTTOM,
                              margin: const EdgeInsets.all(16),
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF6600),
                    disabledBackgroundColor: const Color(0xFFFFB088),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  child: teamController.isLoading.value
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.5,
                          ),
                        )
                      : const Text(
                          "Buat Tim",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
